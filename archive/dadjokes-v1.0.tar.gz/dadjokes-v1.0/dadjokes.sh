#! /usr/bin/bash

curl https://icanhazdadjoke.com/
